﻿namespace WindowsFormsApplication4
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnDados = new System.Windows.Forms.Button();
            this.lbxVetores = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // btnDados
            // 
            this.btnDados.Location = new System.Drawing.Point(127, 53);
            this.btnDados.Name = "btnDados";
            this.btnDados.Size = new System.Drawing.Size(123, 107);
            this.btnDados.TabIndex = 0;
            this.btnDados.Text = "Informar Dados";
            this.btnDados.UseVisualStyleBackColor = true;
            this.btnDados.Click += new System.EventHandler(this.button1_Click);
            // 
            // lbxVetores
            // 
            this.lbxVetores.FormattingEnabled = true;
            this.lbxVetores.Location = new System.Drawing.Point(307, 125);
            this.lbxVetores.Name = "lbxVetores";
            this.lbxVetores.Size = new System.Drawing.Size(564, 342);
            this.lbxVetores.TabIndex = 1;
            this.lbxVetores.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1007, 525);
            this.Controls.Add(this.lbxVetores);
            this.Controls.Add(this.btnDados);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnDados;
        private System.Windows.Forms.ListBox lbxVetores;
    }
}

